import static java.lang.System.out;
import java.util.Scanner;

public class Groceries
{

    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        String Item1;
        out.println("Please list three items from your grocery list!");
        out.println("What is Item 1? ");
        Item1 = keyboard.nextLine();
        String Item2;
        out.println("What is Item 2? ");
        Item2 = keyboard.nextLine();
        String Item3;
        out.print("What is Item 3? ");
        Item3 = keyboard.nextLine();

        int Quanity;
        out.println("Now, please enter the quanity of each item.");
        out.println("How many of " + Item1 +" ? ");
        Quanity = keyboard.nextInt();
        keyboard.skip("\n");
        out.println("How many of " + Item2 + "?");
        Quanity = keyboard.nextInt();
        keyboard.skip("\n");
        out.print("How many of " + Item3 +"?");
        Quanity = keyboard.nextInt();
        keyboard.skip("\n");

        int Cost;
        out.println("Now, please enter the cost of each item?");
        out.println("How much does one " + Item1 +" cost?");
        Cost = keyboard.nextInt();
        keyboard.skip("\n");
        out.println("How much does one " + Item2 +" cost?");
        Cost = keyboard.nextInt();
        keyboard.skip("\n");
        out.print("How much does one " + Item3 +" cost?");
        Cost = keyboard.nextInt();
        keyboard.skip("\n");

        

    }
}